blockMesh
topoSet -dict system/topoSetDict-createAllCellZones
tauFoam
